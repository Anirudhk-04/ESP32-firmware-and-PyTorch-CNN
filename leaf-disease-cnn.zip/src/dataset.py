def get_loaders():
    pass
