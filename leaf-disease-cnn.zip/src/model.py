class BasicCNN:
    pass
