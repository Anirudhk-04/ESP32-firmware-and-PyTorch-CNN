def save_checkpoint():
    pass
